from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import pickle

app = Flask(__name__)

# Load model and feature list
with open('model.pkl', 'rb') as f:
    data = pickle.load(f)  # model.pkl must contain a dictionary
    model = data['model']
    model_features = data['features']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        bedrooms = int(request.form['bedrooms'])
        area = float(request.form['area'])  # sqft_living
        zipcode = request.form['zipcode']
        yr_built = int(request.form['yr_built'])

        # Calculate age
        age = 2025 - yr_built

        # Create input dictionary
        input_dict = {
            'bedrooms': bedrooms,
            'area': area,
            'age': age
        }

        # One-hot encode zipcode like in training
        for feature in model_features:
            if feature.startswith('zipcode_'):
                input_dict[feature] = 1 if feature == f'zipcode_{zipcode}' else 0

        # Convert to DataFrame and match feature order
        X_input = pd.DataFrame([input_dict])
        X_input = X_input.reindex(columns=model_features, fill_value=0)

        # Make prediction
        prediction = model.predict(X_input)[0]

        return render_template('index.html', data=int(prediction))

    except Exception as e:
        return render_template('index.html', data=f"Error: {e}")

if __name__ == '__main__':
    app.run(debug=True)
