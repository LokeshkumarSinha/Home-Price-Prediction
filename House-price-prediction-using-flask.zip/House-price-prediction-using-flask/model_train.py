import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import pickle

# Load dataset
df = pd.read_csv('house_data.csv')

# Drop unnecessary columns
df = df.drop(['id', 'date', 'lat', 'long'], axis=1)

# Create 'age' column
df['age'] = 2025 - df['yr_built']

# Rename sqft_living to 'area'
df = df.rename(columns={'sqft_living': 'area'})

# Use selected features
df = df[['bedrooms', 'area', 'zipcode', 'age', 'price']]

# One-hot encode 'zipcode'
df = pd.get_dummies(df, columns=['zipcode'], drop_first=True)

# Save column order for prediction
model_features = df.drop('price', axis=1).columns.tolist()

# Define features and target
X = df[model_features]
y = df['price']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Models
lr = LinearRegression().fit(X_train, y_train)
ridge = Ridge().fit(X_train, y_train)
lasso = Lasso().fit(X_train, y_train)

# Evaluate
models = {'LinearRegression': lr, 'Ridge': ridge, 'Lasso': lasso}
best_model = None
best_score = -np.inf

for name, model in models.items():
    score = r2_score(y_test, model.predict(X_test))
    print(f"{name} R² Score: {score:.4f}")
    if score > best_score:
        best_model = model
        best_score = score

# Save model + feature columns
with open('model.pkl', 'wb') as f:
    pickle.dump({'model': best_model, 'features': model_features}, f)

print("✅ Best model saved as model.pkl with feature list.")
